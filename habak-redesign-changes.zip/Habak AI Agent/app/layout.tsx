import "./globals.css";
import type { ReactNode } from "react";
import { IBM_Plex_Sans_Hebrew } from "next/font/google";
import { Providers } from "./providers";

// One font for the whole app (Hebrew + Latin).
const plex = IBM_Plex_Sans_Hebrew({
  subsets: ["hebrew", "latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-plex",
  display: "swap",
});

export const metadata = {
  title: "חב״ק AI | Habak AI",
  description: "Internal knowledge assistant for Habak at Midburn",
};

// viewportFit: "cover" lets content extend under the iPhone notch/home
// indicator safe areas so env(safe-area-inset-*) (used near the input bar in
// app/page.tsx) resolves to real values instead of 0.
export const viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

// Hebrew/RTL by default so the initial server-rendered HTML matches
// DEFAULT_LOCALE in lib/i18n/dictionary.ts — no flash of English/LTR before
// LanguageProvider mounts. LanguageProvider flips these on the client only
// if the user has previously toggled to English (see localStorage restore).
export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="he" dir="rtl" className={plex.variable}>
      <body className="bg-ctl-night text-ctl-text font-sans antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
