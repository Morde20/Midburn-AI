"use client";

/**
 * components/SourceCard.tsx
 *
 * One retrieved source passage shown next to (desktop) or under (mobile) an
 * assistant answer. Collapsed: title + first lines. Expanded: the full
 * passage, scrollable inside the card if it is long.
 */

import { useState } from "react";
import { useLanguage } from "@/lib/i18n/LanguageProvider";

export type SourceItem = { title: string; content: string };

export function SourceCard({ source, index }: { source: SourceItem; index: number }) {
  const [open, setOpen] = useState(false);
  const { t, dir } = useLanguage();

  return (
    <div
      dir={dir}
      className="rounded-xl border border-ctl-line bg-ctl-panel2 px-3.5 py-3 text-start"
    >
      <p className="text-xs text-ctl-amber font-medium mb-1.5">
        {index + 1}. {source.title}
      </p>
      <p
        className={`text-[13px] leading-relaxed text-ctl-text/90 whitespace-pre-wrap ${
          open ? "max-h-56 overflow-y-auto pe-1" : "line-clamp-3"
        }`}
      >
        {source.content}
      </p>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="mt-2 text-xs text-ctl-muted hover:text-ctl-amber"
      >
        {open ? t.chat.showLess : t.chat.showMore}
      </button>
    </div>
  );
}
